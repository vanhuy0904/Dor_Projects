import os

from oracledb.pool import create_pool
from flask import Flask, send_from_directory, request, jsonify

from database import *

app = Flask(__name__, static_folder='static')

pool = create_pool(
    dsn="admin/abcABC1234@localhost/disneypdb1",
    min=1,
    max=10
)


@app.route('/api/songs')
def all_songs():
    s_list = GetSongsList(pool).run()
    res = []
    for sid, s_title in s_list:
        res.append({"song_id": sid, "song_title": s_title})
    return jsonify(status="success", songs=res)


@app.route('/api/search_songs')
def search_songs():
    movie_filter = request.args.get('movie_filter', default=None, type=str)
    performer_filter = request.args.get('performer_filter', default=None, type=str)
    writer_filter = request.args.get('writer_filter', default=None, type=str)
    operation = request.args.get('operation', default='OR', type=str)

    movie_filter = movie_filter or None
    performer_filter = performer_filter or None
    writer_filter = writer_filter or None

    s_list = SearchSong(
        pool,
        movie_filter=movie_filter,
        performer_filter=performer_filter,
        writer_filter=writer_filter,
        op=operation
    ).run()

    res = []
    for sid, s_title in s_list:
        res.append({"song_id": sid, "song_title": s_title})
    return jsonify(status="success", songs=res)


@app.route('/api/songs/<int:song_id>/text')
def song_text(song_id):
    res = GetSongText(pool, song_id=song_id).run()

    return jsonify(status="success", text=res)


@app.route('/api/songs/<int:song_id>/metadata')
def song_metadata(song_id):
    res = GetSongMetadata(pool, song_id=song_id).run()

    return jsonify(status="success", metadata=res.to_json())


@app.route('/api/songs/<song_id>', methods=['POST'])
def delete_song(song_id):
    DeleteSong(pool, song_id=song_id).run()
    return jsonify(status="success")


@app.route('/api/new_song', methods=['POST'])
def new_song():
    song = request.get_json()
    metadata_dict = song.copy()
    del metadata_dict["lyrics"]
    metadata_record = SongMetadataRecord(**metadata_dict)

    # in case the file is in our weird test format we will normalize it here
    sep = '-' * 50
    lyrics = song["lyrics"]
    if sep in lyrics:
        lyrics = lyrics.split(sep)[1]

    AddNewSong(pool, metadata_record, lyrics).run()

    return jsonify(status="success")


@app.route('/api/words_info')
def words_info():
    # word_filter = request.args.get('word_filter', default=None, type=str)
    song_id_filter = request.args.get('song_id_filter', default=None, type=int)
    group_id_filter = request.args.get('group_id_filter', default=None, type=int)

    res = GetWordsLocations(
        pool,
        word_filter=None,
        song_id_filter=song_id_filter,
        group_id_filter=group_id_filter
    ).run()

    res2 = CountWordsGroups(pool).run()

    # now compress the array as a dict, this way we send the data much faster to the client
    words_information = {'locations': {}, 'groups': res2}
    for rec in res:
        words_information['locations'].setdefault(rec[0], []).append(rec[1:])

    return jsonify(status="success", info=words_information)


@app.route('/api/word_at_location')
def word_at_location():
    song_id = request.args.get('song_id', type=int)
    verse_num = request.args.get('verse_num', type=int)
    line_num = request.args.get('line_num', type=int)
    word_num = request.args.get('word_num', type=int)

    if not all((song_id, verse_num, line_num, word_num)):
        return jsonify(status="error", error="missing fields in location")

    res = GetWordAtLocation(
        pool,
        song_id=song_id,
        verse_num=verse_num,
        line_num=line_num,
        word_num=word_num
    ).run()

    if res is None:
        return jsonify(status="error", error="invalid word location")
    return jsonify(status="success", word=res)


@app.route('/api/location_environment')
def location_environment():
    movie_name = request.args.get('movie_name', type=str)
    song_title = request.args.get('song_title', type=str)
    verse_num = request.args.get('verse_num', type=int)
    line_num = request.args.get('line_num', type=int)

    params = {"movie_name": movie_name,
              "song_title": song_title,
              "verse_num": verse_num}

    # now we will get the line before, our line and line after
    before_line = GetLineByLocation(pool, line_num=line_num - 1, **params).run()
    our_line = GetLineByLocation(pool, line_num=line_num, **params).run()
    after_line = GetLineByLocation(pool, line_num=line_num + 1, **params).run()

    if our_line is None:
        return jsonify(status="error", error="invalid location")

    res = ""
    if before_line is not None:
        res += before_line + "\n"
    res += our_line + "\n"
    if after_line is not None:
        res += after_line + "\n"

    return jsonify(status="success", env=res)


@app.route('/api/word_groups')
def word_groups():
    word = request.args.get('word', default=None, type=str)
    if word is None:
        return jsonify(status="error", error="word not given")

    res = ListWordGroups(pool, word=word).run()
    return jsonify(status="success", groups=res)


@app.route('/api/word_id')
def get_word_id():
    word = request.args.get('word', default=None, type=str)
    if word is None:
        return jsonify(status="error", error="word not given")

    res = GetWordID(pool, word=word).run()
    if res is None:
        return jsonify(status="error", error="word not found")

    return jsonify(status="success", word_id=res)


@app.route('/api/groups')
def all_groups():
    g_list = ListGroups(pool).run()
    res = []
    for gid, g_name in g_list:
        res.append({"group_id": gid, "group_name": g_name})
    return jsonify(status="success", groups=res)


@app.route('/api/groups/<group_id>', methods=['POST'])
def delete_group(group_id):
    DeleteGroup(pool, group_id=group_id).run()
    return jsonify(status="success")


@app.route('/api/groups/new/<group_name>', methods=['POST'])
def new_group(group_name):
    res = CreateNewGroup(pool, group_name=group_name).run()
    if res > 0:
        return jsonify(status="success")
    return jsonify(status="error")


@app.route('/api/groups/new_word/<int:group_id>/<int:word_id>', methods=['POST'])
def add_word_to_group(group_id, word_id):
    res = AddWordToGroup(pool, word_id=word_id, group_id=group_id).run()
    if res > 0:
        return jsonify(status="success")
    return jsonify(status="error")


@app.route('/api/groups/remove_word/<int:group_id>/<int:word_id>', methods=['POST'])
def remove_word_from_group(group_id, word_id):
    res = RemoveWordFromGroup(pool, word_id=word_id, group_id=group_id).run()
    if res > 0:
        return jsonify(status="success")
    return jsonify(status="error")


@app.route('/api/groups/<group_id>/words')
def group_words(group_id):
    res = ListGroupWords(pool, group_id=group_id).run()
    return jsonify(status="success", words=res)


@app.route('/api/statistics')
def statistics():
    stats = dict()
    stats["most_common_word"] = GetMostCommonWord(pool).run()
    stats["shortest_word"] = GetShortestWord(pool).run()
    stats["longest_word"] = GetLongestWord(pool).run()
    stats["average_words_in_line"] = GetAvgWordsInLine(pool).run()
    stats["average_lines_in_verse"] = GetAvgLinesInVerse(pool).run()
    stats["average_verses_in_song"] = GetAvgVersesInSong(pool).run()
    return jsonify(status="success", statistics=stats)


@app.route('/api/search_text', methods=['POST'])
def search_text():
    text = request.form.get('text', default=None, type=str)
    if text is None:
        return jsonify(status="error", error="text not given")

    res = FindTextInLine(pool, text).run()
    return jsonify(status="success", results=res)


# Serve App
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != "" and os.path.exists(app.static_folder + '/' + path):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'songs.html')


if __name__ == '__main__':
    app.run(threaded=True)
