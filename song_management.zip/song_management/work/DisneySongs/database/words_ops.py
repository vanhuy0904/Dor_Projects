from database.db_ops_base import DBOperation


class GetWordsLocations(DBOperation):
    def __init__(self, pool, word_filter: str = None, song_id_filter: int = None, group_id_filter: int = None):
        self.word_filter = word_filter
        self.song_id_filter = song_id_filter
        self.group_id_filter = group_id_filter

        super().__init__(pool)

    def _run(self):
        query = """
                SELECT w.Word, m.MovieName, s.SongTitle, v.VerseNo, l.LineNo
                FROM SongsWords sw
                JOIN Songs s ON s.SongID = sw.SongID
                JOIN Verses v ON v.VerseID = sw.VerseID
                JOIN Lines l ON l.LineID = sw.LineID
                JOIN Movies m ON m.MovieID = s.MovieID
                JOIN Words w ON w.WordID = sw.WordID
                LEFT JOIN WordsGroups wg ON w.WordID = wg.WordID
                WHERE 1=1
                """

        args = dict()
        if self.word_filter is not None:
            query += " AND LOWER(w.Word) = :word"
            args["word"] = self.word_filter.lower()

        if self.song_id_filter is not None:
            query += " AND s.SongID = :song_id"
            args["song_id"] = self.song_id_filter

        if self.group_id_filter is not None:
            query += " AND wg.GroupID = :group_id"
            args["group_id"] = self.group_id_filter

        query += " ORDER BY w.Word, v.VerseNo, l.LineNo"

        self._cursor.execute(query, args)
        return self._cursor.fetchall()


class GetWordAtLocation(DBOperation):
    def __init__(self, pool, song_id: int, verse_num: int, line_num: int, word_num: int):
        super().__init__(pool)

        self.song_id = song_id
        self.verse_num = verse_num
        self.line_num = line_num
        self.word_num = word_num

    def _run(self):
        # in case word_num < 1 the query will throw an exception, therefore disallow it here
        if self.word_num < 1:
            return None

        query = """
          SELECT REGEXP_SUBSTR(l.LineText, '[^ ]+', 1, :word_num) AS word
          FROM Lines l
          JOIN Verses v ON l.VerseID = v.VerseID
          JOIN Songs s ON v.SongID = s.SongID
          WHERE s.SongID = :song_id
            AND v.VerseNo = :verse_num
            AND l.LineNo = :line_num
          """
        self._cursor.execute(
            query,
            song_id=self.song_id,
            verse_num=self.verse_num,
            line_num=self.line_num,
            word_num=self.word_num
        )
        result = self._cursor.fetchone()
        if result is not None:
            return result[0]
        return None


class GetWordID(DBOperation):
    def __init__(self, pool, word:str):
        super().__init__(pool)

        self.word = word

    def _run(self):
        sql_query = "SELECT WordID FROM Words WHERE Word = :word"
        self._cursor.execute(sql_query, {"word": self.word})

        # Fetch the result
        result = self._cursor.fetchone()
        if result:
            return result[0]
        return None
