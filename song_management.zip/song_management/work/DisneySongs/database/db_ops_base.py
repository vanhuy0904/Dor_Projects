from oracledb.pool import ConnectionPool


class DBOperation(object):
    def __init__(self, pool: ConnectionPool):
        self._pool = pool
        self._connection = pool.acquire()
        self._cursor = self._connection.cursor()

    def _run(self):
        raise NotImplementedError()

    def run(self):
        ret = self._run()
        self._connection.commit()
        self._connection.close()
        return ret
