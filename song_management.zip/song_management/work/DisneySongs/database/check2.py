from oracledb.pool import create_pool

from database.tables_ops import CreateTables, DeleteTables
from database.songs_ops import AddNewSong, SongMetadataRecord, DeleteSong
from database.words_ops import GetWordAtLocation
from database.groups_ops import CreateNewGroup, ListGroups, AddWordToGroup, RemoveWordFromGroup, ListGroupWords, CountWordsGroups
from database.stats_ops import GetMostCommonWord, GetShortestWord, GetLongestWord, GetAvgWordsInLine, \
    GetAvgLinesInVerse, GetAvgVersesInSong
from database.lines_ops import FindTextInLine

SEP = "--------------------------------------------------"

pool = create_pool(
    dsn="admin/abcABC1234@localhost/disneypdb1",
    min=1,
    max=10
)
op = DeleteTables(pool)
op.run()

op = CreateTables(pool)
op.run()

metadata = SongMetadataRecord(
    title="The Circle of Life",
    movie="The Lion King",
    writer="Elton John and Tim Rice",
    performer="Carmen Twillie, with chorus",
)
op = AddNewSong(
    pool,
    metadata=metadata,
    lyrics=open("../songs/The Lion King/The Circle of Life.txt", "rb").read().decode().split(SEP)[1]
)

op.run()


metadata = SongMetadataRecord(
    title="Let it go",
    movie="Frozen",
    writer="Kristen Anderson-Lopez and Robert Lopez",
    performer="Demi Lovato",
)
op = AddNewSong(
    pool,
    metadata=metadata,
    lyrics=open("../songs/Frozen/Let it Go.txt", "rb").read().decode().split(SEP)[1]
)

op.run()


# op = GetSongsList(pool)
# print(op.run())
#
# op = GetSongText(pool, song_id=1)
# text = op.run()
# print(text)

# op = SearchSong(pool, movie_filter="king")
# res = op.run()
# print(res)
#
# op = GetSongMetadata(pool, song_id=1)
# print(op.run())

# op = GetWordsLocations(pool, song_id_filter=1, word_filter="the")
# res = op.run()
#
# for rec in res:
#     print(rec)


op = GetWordAtLocation(pool, song_id=1, verse_num=1, line_num=2, word_num=3)
res = op.run()
print(res)

op = CreateNewGroup(pool, "g_1")
print(op.run())

op = CreateNewGroup(pool, "g_1")
print(op.run())

op = ListGroups(pool)
print(op.run())

op = AddWordToGroup(pool, word_id=1, group_id=1)
print(op.run())

# op = AddWordToGroup(pool, word_id=1, group_id=9)
# print(op.run())

# DeleteGroup(pool, group_id=1).run()
print(ListGroupWords(pool, group_id=1).run())
# RemoveWordFromGroup(pool, word_id=1, group_id=1).run()
# print(ListGroupWords(pool, group_id=1).run())

# DeleteSong(pool, song_id=1).run()

print(GetMostCommonWord(pool).run())

print(GetShortestWord(pool).run())

print(GetLongestWord(pool).run())

print(GetAvgWordsInLine(pool).run())

print(GetAvgLinesInVerse(pool).run())

print(GetAvgVersesInSong(pool).run())

print(FindTextInLine(pool, text="from t").run())

print(CountWordsGroups(pool).run())