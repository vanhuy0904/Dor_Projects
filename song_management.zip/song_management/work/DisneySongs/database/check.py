import oracledb

# DB_USERNAME = "SYSTEM"
# DB_PASSWORD = "abcABC1234"
#
# connection = oracledb.connect(
#     user=DB_USERNAME,
#     password=DB_PASSWORD,
#     host="localhost",
#     port=1521,
#     service_name="disneypdb1"
# )


pool = oracledb.create_pool(
    dsn="admin/abcABC1234@localhost/disneypdb1",
    min=1,
    max=10
)

connection = pool.acquire()

cursor = connection.cursor()

cursor.execute("""
        begin
          --Bye Sequences!
          FOR i IN (SELECT us.sequence_name
                      FROM USER_SEQUENCES us) LOOP
            EXECUTE IMMEDIATE 'drop sequence '|| i.sequence_name ||'';
          END LOOP;

          --Bye Tables!
          FOR i IN (SELECT ut.table_name
                      FROM USER_TABLES ut) LOOP
            EXECUTE IMMEDIATE 'drop table '|| i.table_name ||' CASCADE CONSTRAINTS ';
          END LOOP;
        end;""")

cursor.execute("CREATE SEQUENCE performer_id_seq INCREMENT BY 1")
cursor.execute("CREATE SEQUENCE writer_id_seq INCREMENT BY 1")
cursor.execute("CREATE SEQUENCE song_id_seq INCREMENT BY 1")
cursor.execute("CREATE SEQUENCE movie_id_seq INCREMENT BY 1")
cursor.execute("CREATE SEQUENCE group_id_seq INCREMENT BY 1")
cursor.execute("CREATE SEQUENCE word_id_seq INCREMENT BY 1")
cursor.execute("CREATE SEQUENCE verse_id_seq INCREMENT BY 1")
cursor.execute("CREATE SEQUENCE line_id_seq INCREMENT BY 1")

cursor.execute("""
CREATE TABLE Performers (
  PerformerID INTEGER DEFAULT performer_id_seq.nextval NOT NULL PRIMARY KEY, 
  PerformerName VARCHAR(255) NOT NULL UNIQUE
)
""")

cursor.execute("""
CREATE TABLE Movies (
  MovieID INTEGER DEFAULT movie_id_seq.nextval NOT NULL PRIMARY KEY, 
  MovieName VARCHAR(255) NOT NULL UNIQUE
)

""")

cursor.execute("""
CREATE TABLE Writers (
  WriterID INTEGER DEFAULT writer_id_seq.nextval NOT NULL PRIMARY KEY, 
  WriterName VARCHAR(255) NOT NULL UNIQUE
)
""")

cursor.execute("""
CREATE TABLE Songs (
  SongID INTEGER DEFAULT song_id_seq.nextval NOT NULL PRIMARY KEY,
  SongTitle varchar(255) NOT NULL UNIQUE,
  MovieID integer NOT NULL,
  WriterID integer,
  PerformerID integer,
  FOREIGN KEY(MovieID) REFERENCES Movies(MovieID),
  FOREIGN KEY(WriterID) REFERENCES Writers(WriterID),
  FOREIGN KEY(PerformerID) REFERENCES Performers(PerformerID)
)
""")

cursor.execute("""
CREATE TABLE Verses (
  VerseID INTEGER DEFAULT verse_id_seq.nextval NOT NULL PRIMARY KEY,
  SongID integer NOT NULL, 
  VerseNo integer NOT NULL, 
  FOREIGN KEY(SongID) REFERENCES Songs(SongID)
)
""")

cursor.execute("""
CREATE TABLE Lines (
  LineID INTEGER DEFAULT line_id_seq.nextval NOT NULL PRIMARY KEY,
  "LineNo" integer NOT NULL,
  LineText varchar(255) NOT NULL,
  VerseID integer NOT NULL,
  FOREIGN KEY(VerseID) REFERENCES Verses(VerseID)
)
""")

cursor.execute("""
CREATE TABLE Words (
  WordID INTEGER DEFAULT word_id_seq.nextval NOT NULL PRIMARY KEY,
  Word varchar(255) NOT NULL UNIQUE
)

""")

cursor.execute("""
CREATE TABLE SongsWords (
  WordID integer NOT NULL, 
  SongID integer NOT NULL, 
  VerseID integer NOT NULL, 
  LineID integer NOT NULL, 
  FOREIGN KEY(WordID) REFERENCES Words(WordID), 
  FOREIGN KEY(SongID) REFERENCES Songs(SongID), 
  FOREIGN KEY(VerseID) REFERENCES Verses(VerseID), 
  FOREIGN KEY(LineID) REFERENCES Lines(LineID)
)
""")

cursor.execute("""
CREATE TABLE Groups (
  GroupID INTEGER DEFAULT group_id_seq.nextval NOT NULL PRIMARY KEY,
  GroupName varchar(255) NOT NULL UNIQUE
)
""")

cursor.execute("""
CREATE TABLE WordsGroups (
  WordID integer NOT NULL, 
  GroupID integer NOT NULL, 
  FOREIGN KEY(WordID) REFERENCES Words(WordID), 
  FOREIGN KEY(GroupID) REFERENCES Groups(GroupID)
)
""")

pool.drop(connection)
