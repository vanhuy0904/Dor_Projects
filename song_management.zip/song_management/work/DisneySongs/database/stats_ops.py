from database.db_ops_base import DBOperation


class GetMostCommonWord(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        query = """
            SELECT Word, WordCount
            FROM (
                SELECT Word, COUNT(*) AS WordCount
                FROM Words w
                JOIN SongsWords sw ON w.WordID = sw.WordID
                GROUP BY Word
                ORDER BY COUNT(*) DESC
            )
            WHERE ROWNUM = 1
        """
        self._cursor.execute(query)
        return self._cursor.fetchone()


class GetShortestWord(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        query = """
            SELECT Word
            FROM Words
            ORDER BY LENGTH(Word) ASC
            FETCH FIRST 1 ROW ONLY
        """
        self._cursor.execute(query)
        word = self._cursor.fetchone()
        if word:
            return word[0]
        return None


class GetLongestWord(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        query = """
            SELECT Word
            FROM Words
            ORDER BY LENGTH(Word) DESC
            FETCH FIRST 1 ROW ONLY
        """
        self._cursor.execute(query)
        word = self._cursor.fetchone()
        if word:
            return word[0]
        return None


class GetAvgWordsInLine(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        query = """
            SELECT AVG(word_count)
            FROM (SELECT LineID, COUNT(WordID) AS word_count FROM SongsWords
                  GROUP BY LineID)
        """
        self._cursor.execute(query)
        res = self._cursor.fetchone()
        if res:
            return res[0]
        return None


class GetAvgLinesInVerse(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        query = """
            SELECT AVG(line_count)
            FROM (SELECT  COUNT(LineID) AS line_count FROM Lines
            GROUP BY VerseId)
        """
        self._cursor.execute(query)
        res = self._cursor.fetchone()
        if res:
            return res[0]
        return None


class GetAvgVersesInSong(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        query = """
            SELECT AVG(verse_count)
            FROM (SELECT  COUNT(VerseID) AS verse_count FROM Verses
            GROUP BY SongID)
        """
        self._cursor.execute(query)
        res = self._cursor.fetchone()
        if res:
            return res[0]
        return None
