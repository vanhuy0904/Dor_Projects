import string

from database.db_ops_base import DBOperation


class SongMetadataRecord(object):
    def __init__(self, title: str, movie: str, writer: str, performer: str):
        self.performer = performer or None
        self.writer = writer or None
        self.movie = movie
        self.title = title

    def to_json(self):
        return {
            'performer': self.performer,
            'writer': self.writer,
            'movie': self.movie,
            'title': self.title
        }

    def __str__(self):
        return f"Song Title: {self.title}\nMovie: {self.movie}\nWriter: {self.writer}\nPerformer: {self.performer}"


class AddNewSong(DBOperation):
    def __init__(self, pool, metadata: SongMetadataRecord, lyrics: str):
        self.lyrics = lyrics
        self.performer = metadata.performer
        self.writer = metadata.writer
        self.movie = metadata.movie
        self.title = metadata.title

        super().__init__(pool)

    def _insert_new_song_movie(self, movie_name):
        # Check if the movie exists
        self._cursor.execute("SELECT MovieID FROM Movies WHERE MovieName = :movie_name", movie_name=movie_name)
        ret_it = self._cursor.fetchone()
        if ret_it is not None:
            return ret_it[0]

        ret_it = self._cursor.var(int)

        self._cursor.execute(
            """
            INSERT INTO Movies (MovieName) VALUES (:movie_name)
            RETURNING MovieID INTO :ret_id
            """, movie_name=movie_name, ret_id=ret_it)
        return ret_it.getvalue()[0]

    def _insert_new_song_writer(self, writer_name):
        # Check if the movie exists
        self._cursor.execute("SELECT WriterID FROM Writers WHERE WriterName = :writer_name", writer_name=writer_name)
        m_id = self._cursor.fetchone()
        if m_id is not None:
            return m_id[0]

        ret_it = self._cursor.var(int)

        self._cursor.execute(
            """
            INSERT INTO Writers (WriterName) VALUES (:writer_name)
            RETURNING WriterID INTO :ret_id
            """, writer_name=writer_name, ret_id=ret_it)
        return ret_it.getvalue()[0]

    def _insert_new_song_performer(self, performer_name):
        # Check if the movie exists
        self._cursor.execute(
            "SELECT PerformerID FROM Performers WHERE PerformerName = :performer_name",
            performer_name=performer_name)
        m_id = self._cursor.fetchone()
        if m_id is not None:
            return m_id[0]

        ret_it = self._cursor.var(int)

        self._cursor.execute(
            """
            INSERT INTO Performers (PerformerName) VALUES (:performer_name)
            RETURNING PerformerID INTO :ret_id
            """, performer_name=performer_name, ret_id=ret_it)
        return ret_it.getvalue()[0]

    @staticmethod
    def _get_word_letters(word):
        ret_str = ""
        for c in word:
            if c in string.ascii_letters:
                ret_str += c
        return ret_str

    def _insert_new_word(self, song_id, verse_id, line_id, word):
        # TODO: do we care about duplicate word in the same line?
        # first - normalize the word
        word = self._get_word_letters(word)

        # check if word exist
        self._cursor.execute(
            "SELECT WordID FROM Words WHERE Word = :word",
            word=word)
        word_id = self._cursor.fetchone()

        # word doesn't exist insert it now
        if word_id is None:
            word_id = self._cursor.var(int)
            self._cursor.execute(
                """
                INSERT INTO Words (Word) VALUES (:word)
                RETURNING WordID INTO :word_id
                """, word=word, word_id=word_id)
            word_id = word_id.getvalue()

        word_id = word_id[0]

        # save the current word position
        self._cursor.execute("""
        INSERT INTO SongsWords (WordID, SongID, VerseID, LineID)
        VALUES (:word_id, :song_id, :verse_id, :line_id)
        """, word_id=word_id, song_id=song_id, verse_id=verse_id, line_id=line_id)

    def _insert_new_song_lyrics(self, song_id, lyrics):

        # first normalize the lines from windows to linux
        lyrics = lyrics.replace("\r\n", "\n")
        # remove empty lines at the start / end
        lyrics = lyrics.strip("\n")

        # split the songs into verses
        for verse_num, verse in enumerate(lyrics.split("\n\n")):

            verse_id = self._cursor.var(int)

            self._cursor.execute("""
            INSERT INTO Verses (SongID, VerseNo) VALUES (:song_id, :verse_no) 
            RETURNING VerseID INTO :verse_id
            """, song_id=song_id, verse_no=verse_num + 1, verse_id=verse_id)
            verse_id = verse_id.getvalue()[0]

            # split the verse into lines
            for line_num, line in enumerate(verse.split("\n")):

                line_id = self._cursor.var(int)
                self._cursor.execute("""
                INSERT INTO Lines (LineNo, LineText, VerseID) VALUES (:line_num, :line_text, :verse_id) 
                RETURNING LineID INTO :line_id
                """, line_num=line_num + 1, line_text=line, verse_id=verse_id, line_id=line_id)
                line_id = line_id.getvalue()[0]

                # split the line into words
                for word in line.split(" "):
                    try:
                        self._insert_new_word(song_id, verse_id, line_id, word.lower())
                    except:
                        print("weird word - " + word + " ignoring!")

    def _run(self):
        writer_id = None
        performer_id = None
        movie_id = self._insert_new_song_movie(self.movie)

        if self.writer is not None:
            writer_id = self._insert_new_song_writer(self.writer)
        if self.performer is not None:
            performer_id = self._insert_new_song_performer(self.performer)

        song_id = self._cursor.var(int)
        self._cursor.execute("""
        INSERT INTO Songs (SongTitle, MovieID, WriterID, PerformerID)
        VALUES (:song_title, :movie_id, :writer_id, :performer_id)
        RETURNING SongID INTO :song_id
        """, song_title=self.title, movie_id=movie_id, writer_id=writer_id, performer_id=performer_id, song_id=song_id)

        song_id = song_id.getvalue()[0]

        self._insert_new_song_lyrics(song_id, self.lyrics)


class GetSongsList(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        # Fetch the song ID and song name from the Songs table
        query = "SELECT SongID, SongTitle FROM Songs"
        self._cursor.execute(query)
        return self._cursor.fetchall()


class GetSongText(DBOperation):
    def __init__(self, pool, song_id: int):
        self.song_id = song_id

        super().__init__(pool)

    def _run(self):
        # Fetch the song lyrics based on the song ID
        query = """
        SELECT L.LineText, V.VerseID
        FROM Songs S
        JOIN Verses V ON S.SongID = V.SongID
        JOIN Lines L ON V.VerseID = L.VerseID
        WHERE S.SongID = :song_id
        ORDER BY V.VerseNo, L.LineNo
        """
        self._cursor.execute(query, song_id=self.song_id)
        lyrics = self._cursor.fetchall()

        if lyrics is None:
            pass
            # TODO: raise database exception

        song_text = ""
        cur_verse_id = lyrics[0][1]

        for record in lyrics:
            line, verse_id = record
            if verse_id != cur_verse_id:
                cur_verse_id = verse_id
                song_text += "\n"

            song_text += line + "\n"

        return song_text


class SearchSong(DBOperation):
    def __init__(self,
                 pool,
                 movie_filter: str = None,
                 performer_filter: str = None,
                 writer_filter: str = None,
                 op='OR'):
        self.movie_filter = movie_filter
        self.performer_filter = performer_filter
        self.writer_filter = writer_filter
        self.op = op

        super().__init__(pool)

    def _run(self):
        if self.op not in ["OR", "AND"]:
            pass
            # TODO : raise db exception

        # LEFT join for performers / writers because they may contain null values

        query = """
         SELECT S.SongID, s.SongTitle
         FROM Songs S
         JOIN Movies M ON S.MovieID = M.MovieID
         LEFT JOIN Performers P ON S.PerformerID = P.PerformerID
         LEFT JOIN Writers W ON S.WriterID = W.WriterID"""

        args = dict()
        if any([self.movie_filter, self.writer_filter, self.performer_filter]):
            query += "\nWHERE "

        if self.movie_filter is not None:
            query += " UPPER(M.MovieName) LIKE '%' || :movie_name || '%' "
            args["movie_name"] = self.movie_filter.upper()

        if self.performer_filter is not None:
            if self.movie_filter is not None:
                query += " " + self.op + " "

            query += " UPPER(P.PerformerName) LIKE '%' || :performer_name || '%' "
            args["performer_name"] = self.performer_filter.upper()

        if self.writer_filter is not None:
            if any([self.movie_filter, self.performer_filter]):
                query += " " + self.op + " "

            query += " UPPER(W.WriterName) LIKE '%' || :writer_name || '%' "
            args["writer_name"] = self.writer_filter.upper()

        self._cursor.execute(query, args)
        song_ids = self._cursor.fetchall()

        return song_ids


class GetSongMetadata(DBOperation):
    def __init__(self, pool, song_id: int):
        self.song_id = song_id

        super().__init__(pool)

    def _run(self):
        query = """
                SELECT s.SongTitle, m.MovieName, w.WriterName, p.PerformerName
                FROM Songs s
                JOIN Movies m ON s.MovieID = m.MovieID
                LEFT JOIN Writers w ON s.WriterID = w.WriterID
                LEFT JOIN Performers p ON s.PerformerID = p.PerformerID
                WHERE s.SongID = :song_id
                """
        self._cursor.execute(query, song_id=self.song_id)
        metadata_raw = self._cursor.fetchone()
        if metadata_raw is None:
            return None

        metadata = SongMetadataRecord(
            title=metadata_raw[0],
            movie=metadata_raw[1],
            writer=metadata_raw[2],
            performer=metadata_raw[3]
        )
        return metadata


class DeleteSong(DBOperation):
    def __init__(self, pool, song_id: int):
        self.song_id = song_id

        super().__init__(pool)

    def _run(self):
        query = """
        DELETE FROM Songs
        WHERE SongID = :song_id
        """
        # This will also delete verses,  s, SongsWords and WordsGroup (delete cascade)
        # TODO: way may want to add a trigger to delete word and song metadata like movie and performer
        self._cursor.execute(query, song_id=self.song_id)
