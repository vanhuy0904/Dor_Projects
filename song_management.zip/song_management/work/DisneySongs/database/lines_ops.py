from database.db_ops_base import DBOperation


class GetLineByLocation(DBOperation):
    def __init__(self, pool, movie_name: str, song_title: str, verse_num: int, line_num: int):
        self.movie_name = movie_name
        self.song_title = song_title
        self.verse_num = verse_num
        self.line_num = line_num

        super().__init__(pool)

    def _run(self):
        query = """
        SELECT l.LineText
        FROM Lines l
        JOIN Verses v ON l.VerseID = v.VerseID
        JOIN Songs s ON v.SongID = s.SongID
        JOIN Movies m ON s.MovieID = m.MovieID
        WHERE m.MovieName = :movie_name
          AND s.SongTitle = :song_title
          AND v.VerseNo = :verse_num
          AND l.LineNo = :line_num
        """

        self._cursor.execute(
            query,
            movie_name=self.movie_name,
            song_title=self.song_title,
            verse_num=self.verse_num,
            line_num=self.line_num
        )

        result = self._cursor.fetchone()
        if result:
            return result[0]
        return None


class FindTextInLine(DBOperation):
    def __init__(self, pool, text: str):
        self.text = text

        super().__init__(pool)

    def _run(self):
        query = """
            SELECT l.LineText
            FROM Lines l
            WHERE LOWER(l.LineText) LIKE '%' || LOWER(:search_string) || '%'
        """
        self._cursor.execute(query, search_string=self.text)
        return self._cursor.fetchall()


