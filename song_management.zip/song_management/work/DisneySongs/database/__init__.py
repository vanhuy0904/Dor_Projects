from .songs_ops import (
    SongMetadataRecord,
    AddNewSong,
    DeleteSong,
    GetSongMetadata,
    SearchSong,
    GetSongsList,
    GetSongText
)

from .words_ops import (
    GetWordAtLocation,
    GetWordsLocations,
    GetWordID
)

from .groups_ops import (
    CreateNewGroup,
    DeleteGroup,
    ListGroups,
    AddWordToGroup,
    RemoveWordFromGroup,
    ListGroupWords,
    ListWordGroups,
    CountWordsGroups
)

from .lines_ops import (
    GetLineByLocation,
    FindTextInLine
)

from .stats_ops import (
    GetMostCommonWord,
    GetShortestWord,
    GetLongestWord,
    GetAvgWordsInLine,
    GetAvgLinesInVerse,
    GetAvgVersesInSong
)
