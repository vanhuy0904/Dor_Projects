from database.db_ops_base import DBOperation


class CreateNewGroup(DBOperation):
    def __init__(self, pool, group_name: str):
        self.group_name = group_name

        super().__init__(pool)

    def _run(self):
        query = """
            INSERT INTO Groups (GroupName)
            SELECT :group_name
            FROM dual
            WHERE NOT EXISTS (
                SELECT 1
                FROM Groups
                WHERE GroupName = :group_name
            )
               """
        self._cursor.execute(query, group_name=self.group_name)
        return self._cursor.rowcount


class ListGroups(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        query = """
            SELECT GroupID, GroupName
            FROM Groups
        """
        self._cursor.execute(query)
        return self._cursor.fetchall()


class AddWordToGroup(DBOperation):
    def __init__(self, pool, word_id: int, group_id: int):
        self.word_id = word_id
        self.group_id = group_id

        super().__init__(pool)

    def _run(self):
        query = """
           INSERT INTO WordsGroups (WordID, GroupID)
           SELECT :word_id, :group_id
           FROM dual
           WHERE NOT EXISTS (
               SELECT 1
               FROM WordsGroups
               WHERE WordID = :word_id
               AND GroupID = :group_id
           )
            AND EXISTS (
                SELECT 1
                FROM Words
                WHERE WordID = :word_id
            )
            AND EXISTS (
                SELECT 1
                FROM Groups
                WHERE GroupID = :group_id
            )
           """
        self._cursor.execute(query, word_id=self.word_id, group_id=self.group_id)

        return self._cursor.rowcount


class RemoveWordFromGroup(DBOperation):
    def __init__(self, pool, word_id: int, group_id: int):
        self.word_id = word_id
        self.group_id = group_id

        super().__init__(pool)

    def _run(self):
        query = """
        DELETE FROM WordsGroups
        WHERE WordID = :word_id
        AND GroupID = :group_id
        """
        self._cursor.execute(query, word_id=self.word_id, group_id=self.group_id)
        return self._cursor.rowcount


class DeleteGroup(DBOperation):
    def __init__(self, pool, group_id: int):
        self.group_id = group_id

        super().__init__(pool)

    def _run(self):
        query = """
          DELETE FROM Groups
          WHERE GroupID = :group_id
          """

        # Deleting the group will also delete all the references in WordsGroups (Delete cascade)
        self._cursor.execute(query, group_id=self.group_id)


class ListGroupWords(DBOperation):
    def __init__(self, pool, group_id: int):
        self.group_id = group_id

        super().__init__(pool)

    def _run(self):
        query = """
        SELECT w.WordID, w.Word
        FROM Words w
        JOIN WordsGroups wg ON w.WordID = wg.WordID
        WHERE wg.GroupID = :group_id
        """
        self._cursor.execute(query, group_id=self.group_id)
        return self._cursor.fetchall()


class ListWordGroups(DBOperation):
    def __init__(self, pool, word: str):
        self.word = word

        super().__init__(pool)

    def _run(self):
        query = """
          SELECT g.GroupID, g.GroupName
          FROM Words w
          JOIN WordsGroups wg ON w.WordID = wg.WordID
          JOIN Groups g ON wg.GroupID = g.GroupID
          WHERE w.Word = :word
          """

        self._cursor.execute(query, word=self.word)

        # Fetch all the results
        return self._cursor.fetchall()


class CountWordsGroups(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        query = """
            SELECT w.Word, COUNT(wg.GroupID) AS Number_of_Groups
            FROM Words w
            LEFT JOIN WordsGroups wg ON w.WordID = wg.WordID
            GROUP BY w.Word
          """

        self._cursor.execute(query)

        # Convert the results into a dict
        res = dict()
        for key, val in self._cursor.fetchall():
            res[key] = val
        return res
