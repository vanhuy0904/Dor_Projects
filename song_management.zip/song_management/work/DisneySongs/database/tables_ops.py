from database.db_ops_base import DBOperation


class DeleteTables(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        self._cursor.execute("""
                begin
                  --Bye Sequences!
                  FOR i IN (SELECT us.sequence_name
                              FROM USER_SEQUENCES us) LOOP
                    EXECUTE IMMEDIATE 'drop sequence '|| i.sequence_name ||'';
                  END LOOP;

                  --Bye Tables!
                  FOR i IN (SELECT ut.table_name
                              FROM USER_TABLES ut) LOOP
                    EXECUTE IMMEDIATE 'drop table '|| i.table_name ||' CASCADE CONSTRAINTS ';
                  END LOOP;
                end;""")


class CreateTables(DBOperation):
    def __init__(self, pool):
        super().__init__(pool)

    def _run(self):
        self._cursor.execute("CREATE SEQUENCE performer_id_seq INCREMENT BY 1")
        self._cursor.execute("CREATE SEQUENCE writer_id_seq INCREMENT BY 1")
        self._cursor.execute("CREATE SEQUENCE song_id_seq INCREMENT BY 1")
        self._cursor.execute("CREATE SEQUENCE movie_id_seq INCREMENT BY 1")
        self._cursor.execute("CREATE SEQUENCE group_id_seq INCREMENT BY 1")
        self._cursor.execute("CREATE SEQUENCE word_id_seq INCREMENT BY 1")
        self._cursor.execute("CREATE SEQUENCE verse_id_seq INCREMENT BY 1")
        self._cursor.execute("CREATE SEQUENCE line_id_seq INCREMENT BY 1")

        self._cursor.execute("""
        CREATE TABLE Performers (
          PerformerID INTEGER DEFAULT performer_id_seq.nextval NOT NULL PRIMARY KEY, 
          PerformerName VARCHAR(255) NOT NULL UNIQUE
        )
        """)

        self._cursor.execute("""
        CREATE TABLE Movies (
          MovieID INTEGER DEFAULT movie_id_seq.nextval NOT NULL PRIMARY KEY, 
          MovieName VARCHAR(255) NOT NULL UNIQUE
        )

        """)

        self._cursor.execute("""
        CREATE TABLE Writers (
          WriterID INTEGER DEFAULT writer_id_seq.nextval NOT NULL PRIMARY KEY, 
          WriterName VARCHAR(255) NOT NULL UNIQUE
        )
        """)

        self._cursor.execute("""
        CREATE TABLE Songs (
          SongID INTEGER DEFAULT song_id_seq.nextval NOT NULL PRIMARY KEY,
          SongTitle varchar(255) NOT NULL UNIQUE,
          MovieID integer NOT NULL,
          WriterID integer,
          PerformerID integer,
          FOREIGN KEY(MovieID) REFERENCES Movies(MovieID),
          FOREIGN KEY(WriterID) REFERENCES Writers(WriterID),
          FOREIGN KEY(PerformerID) REFERENCES Performers(PerformerID)
        )
        """)

        self._cursor.execute("""
        CREATE TABLE Verses (
          VerseID INTEGER DEFAULT verse_id_seq.nextval NOT NULL PRIMARY KEY,
          SongID integer NOT NULL, 
          VerseNo integer NOT NULL, 
          FOREIGN KEY(SongID) REFERENCES Songs(SongID) ON DELETE CASCADE
        )
        """)

        self._cursor.execute("""
        CREATE TABLE Lines (
          LineID INTEGER DEFAULT line_id_seq.nextval NOT NULL PRIMARY KEY,
          LineNo integer NOT NULL,
          LineText varchar(255) NOT NULL,
          VerseID integer NOT NULL,
          FOREIGN KEY(VerseID) REFERENCES Verses(VerseID) ON DELETE CASCADE
        )
        """)

        # self._cursor.execute("""
        # CREATE INDEX LineTextIndex ON Lines(LineText)
        # INDEXTYPE IS CTXSYS.CONTEXT
        # """)

        self._cursor.execute("""
        CREATE TABLE Words (
          WordID INTEGER DEFAULT word_id_seq.nextval NOT NULL PRIMARY KEY,
          Word varchar(255) NOT NULL UNIQUE
        )

        """)

        self._cursor.execute("""
        CREATE TABLE SongsWords (
          WordID integer NOT NULL, 
          SongID integer NOT NULL, 
          VerseID integer NOT NULL, 
          LineID integer NOT NULL, 
          FOREIGN KEY(WordID) REFERENCES Words(WordID) ON DELETE CASCADE, 
          FOREIGN KEY(SongID) REFERENCES Songs(SongID) ON DELETE CASCADE, 
          FOREIGN KEY(VerseID) REFERENCES Verses(VerseID) ON DELETE CASCADE, 
          FOREIGN KEY(LineID) REFERENCES Lines(LineID) ON DELETE CASCADE
        )
        """)

        self._cursor.execute("""
        CREATE TABLE Groups (
          GroupID INTEGER DEFAULT group_id_seq.nextval NOT NULL PRIMARY KEY,
          GroupName varchar(255) NOT NULL UNIQUE
        )
        """)

        self._cursor.execute("""
        CREATE TABLE WordsGroups (
          WordID integer NOT NULL, 
          GroupID integer NOT NULL, 
          FOREIGN KEY(WordID) REFERENCES Words(WordID) ON DELETE CASCADE, 
          FOREIGN KEY(GroupID) REFERENCES Groups(GroupID) ON DELETE CASCADE
        )
        """)
