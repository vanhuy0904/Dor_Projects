# Author: Yakir Avidan
# Disney songs scraper

import os
import requests
from bs4 import BeautifulSoup, SoupStrainer

SONGS_DIR = "songs"
SONGS_URL = "https://www.disneyclips.com/lyrics/"

if not os.path.exists(SONGS_DIR):
    os.makedirs(SONGS_DIR)


def clean_text(text):
    return "".join(x for x in text if x.isalnum() or x == " ")


def crawl_sub_pages(page_url):
    r = requests.get(page_url)
    addresses = []

    for link in BeautifulSoup(r.text, parse_only=SoupStrainer('a'), features="html.parser"):
        if not link.has_attr('href'):
            continue

        addr = link["href"]
        if not addr.endswith(".html") or "http" in addr:
            continue

        # skip weird page
        if "tryeverything" in addr:
            continue

        addresses.append(SONGS_URL + addr)

    return addresses


def save_song(song_url):
    r = requests.get(song_url)

    soup = BeautifulSoup(r.text, parse_only=SoupStrainer('div'), features="html.parser")
    song_name = soup.find("h1").get_text()
    print("Processing song - " + song_name)

    main_div = soup.find("div", {"class": "main"})
    song_text = main_div.find("p")
    for line_break in song_text.findAll('br'):
        line_break.replaceWith("\r\n")

    song_text = song_text.get_text()
    song_text = song_text.replace("Lyrics transcribed by Disneyclips.com", "")

    info_p = soup.find("p", {"class": "info"})
    info_text = info_p.get_text("\r\n")

    writer = "unknown"
    performer = "unknown"

    write_text = ["Written by", "Composed by", "Written and performed by", "Music and lyrics by"]
    perform_text = ["Performed by", "Sung by", "Written and performed by", "Music and lyrics by"]

    for line in info_text.splitlines():
        for t in write_text:
            if t not in line:
                continue
            writer = line.split(t)[1]
            break

        for p in perform_text:
            if p not in line:
                continue
            performer = line.split(p)[1]
            break

    name_p = soup.find("span", {"class": "un"})
    movie_name = name_p.get_text()

    cleaned_movie_name = clean_text(movie_name)
    dir_name = os.path.join(SONGS_DIR, cleaned_movie_name)
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)

    cleaned_song_name = clean_text(song_name) + ".txt"
    file_name = os.path.join(dir_name, cleaned_song_name)
    with open(file_name, "wb") as f:
        f.write(b"movie: " + movie_name.encode() + b"\r\n")
        f.write(b"writer: " + writer.encode() + b"\r\n")
        f.write(b"performer: " + performer.encode() + b"\r\n")
        f.write(b"-" * 50 + b"\r\n")
        f.write(song_text.encode())


if __name__ == '__main__':
    movies_urls = crawl_sub_pages(SONGS_URL)
    for m_url in movies_urls:
        songs = crawl_sub_pages(m_url)
        for s_url in songs:
            try:
                save_song(s_url)
            except:
                print("error while processing song")
