CREATE TABLE Artists (
    ArtistID NUMBER PRIMARY KEY,
    ArtistName VARCHAR2(255) UNIQUE NOT NULL
);

CREATE TABLE Writers (
    WriterID NUMBER PRIMARY KEY,
    WriterName VARCHAR2(255) UNIQUE NOT NULL
);

CREATE TABLE Songs (
    SongID NUMBER PRIMARY KEY,
    SongName VARCHAR2(255) NOT NULL,
    ArtistID NUMBER,
    FOREIGN KEY (ArtistID) REFERENCES Artists(ArtistID)
);

CREATE TABLE SongWriters (
    SongID NUMBER,
    WriterID NUMBER,
    FOREIGN KEY (SongID) REFERENCES Songs(SongID),
    FOREIGN KEY (WriterID) REFERENCES Writers(WriterID),
    PRIMARY KEY (SongID, WriterID)
);

CREATE TABLE Verses (
    VerseID NUMBER PRIMARY KEY,
    SongID NUMBER,
    VerseNumber NUMBER,
    FOREIGN KEY (SongID) REFERENCES Songs(SongID)
);

CREATE TABLE Lyrics (
    SongID NUMBER,
    VerseID NUMBER,
    LineNumber NUMBER,
    LineText VARCHAR2(4000),
    FOREIGN KEY (SongID) REFERENCES Songs(SongID),
    FOREIGN KEY (VerseID) REFERENCES Verses(VerseID),
    PRIMARY KEY (SongID, VerseID, LineNumber)
);

CREATE TABLE WordGroups (
    GroupID NUMBER PRIMARY KEY,
    GroupName VARCHAR2(255) NOT NULL
);

CREATE TABLE LyricsIndex (
    SongID NUMBER,
    VerseID NUMBER,
    LineNumber NUMBER,
    WordNumber NUMBER,
    Word VARCHAR2(255),
    FOREIGN KEY (SongID, VerseID, LineNumber) REFERENCES Lyrics(SongID, VerseID, LineNumber),
    PRIMARY KEY (SongID, VerseID, LineNumber, WordNumber)
);

CREATE TABLE WordGroupLinks (
    GroupID NUMBER,
    Word VARCHAR2(255),
    SongID NUMBER,
    VerseID NUMBER,
    LineNumber NUMBER,
    WordNumber NUMBER,
    FOREIGN KEY (GroupID) REFERENCES WordGroups(GroupID),
    FOREIGN KEY (SongID, VerseID, LineNumber, WordNumber) REFERENCES LyricsIndex(SongID, VerseID, LineNumber, WordNumber)
);
